export const login = async (credentials: { username: string; password: string }) => {
  // Updated endpoint and payload to match backend expectations
  const response = await fetch('http://localhost:8000/login/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(credentials),
  });

  const data = await response.json();
  if (response.ok) {
    // Store access and refresh tokens if login is successful
    localStorage.setItem('access_token', data.access);
    localStorage.setItem('refresh_token', data.refresh);
    return true;
  } else {
    console.error('Login failed:', data.error || 'Unknown error');
    return false;
  }
};

export const fetchData = async (url: string) => {
  // Retrieve access token from local storage
  const token = localStorage.getItem('access_token');
  const response = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  if (response.status === 401) {
    // If the token has expired, attempt to refresh it
    const refreshed = await refreshAccessToken();
    if (refreshed) {
      // Retry the request with the new token
      return fetchData(url);
    } else {
      throw new Error('Authentication failed');
    }
  }

  if (!response.ok) {
    throw new Error(`Failed to fetch data: ${response.statusText}`);
  }

  return response.json();
};

export const refreshAccessToken = async () => {
  const refreshToken = localStorage.getItem('refresh_token');
  if (!refreshToken) {
    console.error('No refresh token available');
    return false;
  }

  try {
    // Call the token refresh endpoint with the stored refresh token
    const response = await fetch('http://localhost:8000/token/refresh/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh: refreshToken }),
    });

    const data = await response.json();
    if (response.ok && data.access) {
      // Save the new access token to local storage
      localStorage.setItem('access_token', data.access);
      return true;
    } else {
      console.error('Failed to refresh token:', data.error || 'Unknown error');
    }
  } catch (error) {
    console.error('Error during token refresh:', error);
  }

  return false;
};
