export default function AnalyticsPage() {
    return (
      <div className="space-y-4">
        <h1 className="text-3xl font-bold">Analytics</h1>
        <p className="text-gray-600">View your Reddit analytics here.</p>
      </div>
    )
  }
  
  