export default function CommunityPage() {
    return (
      <div className="space-y-4">
        <h1 className="text-3xl font-bold">Community</h1>
        <p className="text-gray-600">Manage your Reddit community here.</p>
      </div>
    )
  }
  
  